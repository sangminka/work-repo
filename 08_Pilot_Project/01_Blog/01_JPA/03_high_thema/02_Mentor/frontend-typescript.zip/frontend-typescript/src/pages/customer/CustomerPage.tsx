//CustomerPage.tsx

import React from 'react'
import CustomerList from '../../components/basic/customer/CustomerList'
import Customer from '../../components/basic/customer/Customer'

function CustomerPage() {
  return (
    <>
    <main id="main">
    {/* ======= Breadcrumbs ======= */}
    <div className="breadcrumbs" data-aos="fade-in">
      <div className="container">
        <h2>About Us</h2>
        <p>Est dolorum ut non facere possimus quibusdam eligendi voluptatem. Quia id aut similique quia voluptas sit quaerat debitis. Rerum omnis ipsam aperiam consequatur laboriosam nemo harum praesentium. </p>
      </div>
    </div>{/* End Breadcrumbs */}   

    <div>
        <Customer/>
    </div>
    </main>
    </>
  )
}

export default CustomerPage