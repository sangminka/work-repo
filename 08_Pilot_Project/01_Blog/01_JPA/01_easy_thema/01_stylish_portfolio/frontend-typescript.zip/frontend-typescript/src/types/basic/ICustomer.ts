export default interface ICustomer {
    cid?: any | null,
    fullName: string,
    email: string
    phone: string
}

