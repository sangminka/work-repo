// ISimpleProduct.ts : 인터페이스
export default interface ISimpleProduct {
    spno?: any | null,
    codeId: number,
    title: string,
    imgPath: string,
    unitPrice: number,
    useYn: string
}