// IFaq.ts : 타입 인터페이스
export default interface IFaq {
    no?: any | null,
    title: string,    
    content: string   
}