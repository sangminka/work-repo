﻿/* eslint-disable */
export default function initWow() {
  // 2) wowjs 플러그인 실행
  // Initiate the wowjs
  new WOW().init();
}
