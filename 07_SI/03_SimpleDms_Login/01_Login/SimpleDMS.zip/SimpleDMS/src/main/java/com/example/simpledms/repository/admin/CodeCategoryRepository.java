package com.example.simpledms.repository.admin;

import com.example.simpledms.model.entity.admin.Code;
import com.example.simpledms.model.entity.admin.CodeCategory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * packageName : com.example.simpledms.repository.admin
 * fileName : CodeCategoryRepository
 * author : GGG
 * date : 2023-11-07
 * description : db에 CRUD 함수들이 있는 인터페이스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-11-07         GGG          최초 생성
 */
@Repository
public interface CodeCategoryRepository extends JpaRepository<CodeCategory,Integer> {
    Page<CodeCategory> findAllByCategoryNameContaining(String categoryName, Pageable pageable);
}
