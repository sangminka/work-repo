package com.example.simpledms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleDmsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SimpleDmsApplication.class, args);
    }

}
