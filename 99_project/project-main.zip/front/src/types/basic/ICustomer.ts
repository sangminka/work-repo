// ICustomer.ts
export default interface ICustomer {
    cid?: any | null,
    fullName: string, // question
    email: string,    // answer
    phone: string     // questioner
}