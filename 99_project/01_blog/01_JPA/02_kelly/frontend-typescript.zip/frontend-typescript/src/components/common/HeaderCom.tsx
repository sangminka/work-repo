import React from 'react';
import { Link, useLocation } from 'react-router-dom';

function HeaderCom() {
  const location = useLocation(); // 현재 페이지의 경로 가져오기

  return (
    <>
      <header id="header" className="fixed-top">
        <div className="container-fluid d-flex justify-content-between align-items-center">
          <h1 className="logo me-auto me-lg-0">
            <Link to="/" className={location.pathname === '/' ? 'active' : ''}>
              Kelly
            </Link>
          </h1>
          <nav id="navbar" className="navbar order-last order-lg-0">
            <ul>
              <li>
                <Link to="/" className={location.pathname === '/' ? 'active' : ''}>
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className={location.pathname === '/about' ? 'active' : ''}>
                  About
                </Link>
              </li>
              <li>
                <Link to="/resume" className={location.pathname === '/resume' ? 'active' : ''}>
                  Resume
                </Link>
              </li>
              <li>
                <Link to="/services" className={location.pathname === '/services' ? 'active' : ''}>
                  Services
                </Link>
              </li>
              <li>
                <Link to="/portfolio" className={location.pathname === '/portfolio' ? 'active' : ''}>
                  Portfolio
                </Link>
              </li>
              <li>
                <Link to="/contact" className={location.pathname === '/contact' ? 'active' : ''}>
                  Contact
                </Link>
              </li>
            </ul>
            <i className="bi bi-list mobile-nav-toggle"></i>
          </nav>
          <div className="header-social-links">
            <a href="#" className="twitter"><i className="bi bi-twitter"></i></a>
            <a href="#" className="facebook"><i className="bi bi-facebook"></i></a>
            <a href="#" className="instagram"><i className="bi bi-instagram"></i></a>
            <a href="#" className="linkedin"><i className="bi bi-linkedin"></i></a>
          </div>
        </div>
      </header>
    </>
  );
}

export default HeaderCom;
